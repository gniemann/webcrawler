import logging
import re
import time

from flask import Flask, jsonify
from flask.json import JSONEncoder
from flask.views import MethodView
from flask_cors import CORS
from flask_wtf import Form
from wtforms import StringField, IntegerField, validators

from crawler import start_crawler, TerminationSentinal, JobModel, JobResultsModel


class CrawlerJSONEncoder(JSONEncoder):
    """Custom JSON encoder which calls object's jsonify() method (if it has one)
    Used to allow PageNode to jsonify itself"""

    def default(self, o):
        if hasattr(o, 'jsonify'):
            return o.jsonify()
        else:
            return JSONEncoder.default(self, o)


url_regex = re.compile(r'''(https?://)?([a-z0-9\-]+\.){1,}[a-z0-9]+((\?|/)[^'" ]*)?''', re.IGNORECASE)


class CrawlerForm(Form):
    """This is the data submitted with the crawler POST request"""
    start_page = StringField('start_page', validators=[validators.regexp(url_regex)])
    depth = IntegerField('depth', default=1)
    end_phrase = StringField('end_phrase', validators=[validators.Optional()])
    search_type = StringField('search_type', default='BFS', validators=[validators.AnyOf(['DFS', 'BFS'])])


# set up the Flask application
app = Flask(__name__)
app.config['WTF_CSRF_ENABLED'] = False
CORS(app)
app.json_encoder = CrawlerJSONEncoder


class Crawler(MethodView):
    """
    API methods for the crawler
    route is /crawler/<optional ID>
    on POST (without <ID>), attempt to start a new job
    on GET (with <ID>), return results since the last GET returned
    """
    def post(self):
        """
        Attempts to start a new crawler job.
        :return: Returns a JSON object
        On success, 'status' is set to 'success' and 'job_id' is the ID of the newly created crawl job. Also,
            'root' is a PageNode of the root URL
        On failure, 'status' is set to 'failure' and 'errors' is a list of error strings why the crawl failed to start
        """
        crawler_data = CrawlerForm(csrf_enabled=False)
        if crawler_data.validate_on_submit():
            root, job_id = start_crawler(crawler_data.start_page.data, crawler_data.search_type.data,
                                         crawler_data.depth.data, crawler_data.end_phrase.data)

            if root:
                return_data = {
                    'status': 'success',
                    'job_id': job_id,
                    'root': root
                }
            else:
                return_data = {
                    'status': 'failure',
                    'errors': ['Invalid URL', ]
                }
        else:
            return_data = {
                'status': 'failure',
                'errors': list(crawler_data.errors.values())
            }

        return jsonify(return_data)

    def get(self, job_id):
        """
        Returns new results from the crawl job
        :param job_id: the ID of the crawl job
        :return:
        If no job with the ID is running, returns status 404
        Otherwise, returns a JSON list of JSONified PageNode objects
        """
        job_key = JobModel.get_by_id(job_id)

        if job_key is None:

            # wait a second - poll might have started too early
            time.sleep(1)
            job_key = JobModel.get_by_id(job_id)
            if job_key is None:
                return "Job not scheduled", 404

        qry = job_key.get_unreturned_results()
        while not qry:
            time.sleep(.5)
            qry = job_key.get_unreturned_results()

        new_nodes = []
        for row in qry:
            new_nodes.extend(row.results)
            row.returned = True
            row.put()

        # check for a termination sentinal
        finished = False
        for node in new_nodes:
            if isinstance(node, TerminationSentinal):
                finished = True
                new_nodes.remove(node)

                #delete the job
                job_key.delete()
                break

        new_nodes.sort(key=lambda n: n.id)

        return jsonify({'finished': finished, 'new_nodes': new_nodes})


crawler_view = Crawler.as_view('crawler')
app.add_url_rule('/crawler/<int:job_id>', view_func=crawler_view, methods=['GET', ])
app.add_url_rule('/crawler', view_func=crawler_view, methods=['POST', ])

if __name__ == '__main__':
    app.run()
