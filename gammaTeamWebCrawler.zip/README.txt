Write up included in this zip under the name "MidpointReview.pdf"

Write up includes URL as well as information as to how to interact with the project.

Hope you enjoy!!!